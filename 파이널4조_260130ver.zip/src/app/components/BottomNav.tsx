import React from 'react';
import { House, Bookmark, User } from 'lucide-react';
import { clsx } from 'clsx';

export type Tab = 'home' | 'bookmark' | 'mypage';

interface BottomNavProps {
  currentTab: Tab;
  onTabChange: (tab: Tab) => void;
}

export function BottomNav({ currentTab, onTabChange }: BottomNavProps) {
  const activeColor = "text-[#3D61F1]";
  const inactiveColor = "text-gray-300";

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-100 flex items-center justify-around z-50 px-2 pb-1">
      <button
        onClick={() => onTabChange('home')}
        className="flex flex-col items-center justify-center p-2 min-w-[64px]"
        aria-label="Home"
      >
        <House
          size={24}
          className={clsx(
            "mb-1 transition-colors fill-current",
            currentTab === 'home' ? activeColor : inactiveColor
          )}
          strokeWidth={0} // Fill style often looks better without stroke or minimal stroke
        />
        <span className={clsx("text-[10px] font-medium", currentTab === 'home' ? activeColor : inactiveColor)}>
          홈
        </span>
      </button>

      <button
        onClick={() => onTabChange('bookmark')}
        className="flex flex-col items-center justify-center p-2 min-w-[64px]"
        aria-label="Bookmark"
      >
        <Bookmark
          size={24}
          className={clsx(
            "mb-1 transition-colors fill-current",
            currentTab === 'bookmark' ? activeColor : inactiveColor
          )}
          strokeWidth={0}
        />
        <span className={clsx("text-[10px] font-medium", currentTab === 'bookmark' ? activeColor : inactiveColor)}>
          북마크
        </span>
      </button>
      
      <button
        onClick={() => onTabChange('mypage')}
        className="flex flex-col items-center justify-center p-2 min-w-[64px]"
        aria-label="My Page"
      >
        <User
          size={24}
          className={clsx(
            "mb-1 transition-colors fill-current",
            currentTab === 'mypage' ? activeColor : inactiveColor
          )}
          strokeWidth={0}
        />
        <span className={clsx("text-[10px] font-medium", currentTab === 'mypage' ? activeColor : inactiveColor)}>
          마이페이지
        </span>
      </button>
    </div>
  );
}
