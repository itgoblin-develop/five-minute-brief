import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: () => void;
}

export function LoginModal({ isOpen, onClose, onLogin }: LoginModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 z-[60] backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-4 right-4 top-1/2 -translate-y-1/2 bg-white rounded-2xl z-[70] p-6 shadow-2xl max-w-sm mx-auto"
          >
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                !
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                더 많은 뉴스가 기다려요
              </h3>
              <p className="text-gray-500 text-sm mb-6 leading-relaxed">
                비회원은 하루 3개의 뉴스만 볼 수 있어요.<br />
                로그인하고 나머지 뉴스도 확인해보세요!
              </p>
              
              <button
                onClick={onLogin}
                className="w-full bg-blue-600 text-white font-bold py-3.5 rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 mb-3"
              >
                나머지 뉴스도 마저 읽기
              </button>
              
              <button
                onClick={onClose}
                className="text-gray-400 text-sm font-medium hover:text-gray-600"
              >
                나중에 하기
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
