import React, { useEffect, useState } from 'react';
import { motion, useScroll, useSpring } from 'motion/react';
import { NewsItem } from '@/app/data/mockNews';

interface NewsDetailProps {
  item: NewsItem;
}

export function NewsDetail({ item }: NewsDetailProps) {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="min-h-screen bg-white pb-20 pt-16">
      <article className="max-w-2xl mx-auto px-5">
        {/* Header Info */}
        <div className="mb-6">
          <h1 className="text-[26px] font-bold text-gray-900 leading-snug mb-2">
            {item.title}
          </h1>
          <div className="flex items-center text-gray-500 text-sm">
            <span className="font-medium text-blue-600 mr-2">{item.source}</span>
            <span>{item.date}</span>
          </div>
        </div>

        {/* AI Summary Box */}
        <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-5 mb-8">
          <div className="flex items-center mb-3">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mr-2" />
            <h3 className="text-sm font-bold text-blue-800">AI 3줄 요약</h3>
          </div>
          <ul className="space-y-2">
            {item.summary.map((line, idx) => (
              <li key={idx} className="text-[15px] text-gray-700 leading-relaxed pl-1">
                • {line}
              </li>
            ))}
          </ul>
        </div>

        {/* Content */}
        <div className="prose prose-lg text-gray-800 leading-loose whitespace-pre-line">
          {item.content}
        </div>
        
        {/* Source Footer */}
        <div className="mt-12 pt-6 border-t border-gray-100 text-center">
          <p className="text-gray-400 text-sm">
            뉴스 출처: {item.source}
          </p>
        </div>
      </article>

      {/* Webtoon Style Scroll Indicator */}
      <div className="fixed bottom-0 left-0 right-0 h-1.5 bg-gray-100 z-50">
        <motion.div
          className="absolute top-0 left-0 bottom-0 bg-blue-600 origin-left"
          style={{ scaleX, width: "100%" }}
        />
      </div>
    </div>
  );
}
