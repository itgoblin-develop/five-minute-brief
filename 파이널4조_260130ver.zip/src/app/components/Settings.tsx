import React, { useState } from 'react';
import { clsx } from 'clsx';
import { Bell, Clock } from 'lucide-react';

interface SettingsProps {
  onLogout: () => void;
}

const DAYS = ['월', '화', '수', '목', '금', '토', '일'];

export function Settings({ onLogout }: SettingsProps) {
  const [selectedDays, setSelectedDays] = useState<string[]>(['월', '화', '수', '목', '금']);
  const [time, setTime] = useState('08:00');

  const toggleDay = (day: string) => {
    if (selectedDays.includes(day)) {
      setSelectedDays(prev => prev.filter(d => d !== day));
    } else {
      setSelectedDays(prev => [...prev, day]);
    }
  };

  return (
    <div className="min-h-screen bg-white pt-16 px-5 pb-10 flex flex-col">
      <div className="flex-1">
        {/* Section Header */}
        <div className="mb-8 mt-4">
          <h2 className="text-xl font-bold text-gray-900 mb-2">알림 설정</h2>
          <p className="text-gray-500 text-sm">
            원하는 요일과 시간에 뉴스를 배달받아 보세요!
          </p>
        </div>

        {/* Days Selector */}
        <div className="mb-8">
          <label className="block text-sm font-bold text-gray-700 mb-4 flex items-center">
            <Bell size={16} className="mr-2 text-blue-600" />
            요일 선택
          </label>
          <div className="flex flex-wrap gap-2">
            {DAYS.map((day) => {
              const isSelected = selectedDays.includes(day);
              return (
                <button
                  key={day}
                  onClick={() => toggleDay(day)}
                  className={clsx(
                    "w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-200",
                    isSelected
                      ? "bg-blue-600 text-white shadow-md shadow-blue-200"
                      : "bg-gray-100 text-gray-400 hover:bg-gray-200"
                  )}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>

        {/* Time Picker */}
        <div className="mb-8">
          <label className="block text-sm font-bold text-gray-700 mb-4 flex items-center">
            <Clock size={16} className="mr-2 text-blue-600" />
            시간 설정
          </label>
          <div className="relative">
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-lg font-medium text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
          </div>
        </div>
      </div>

      {/* Logout Button */}
      <div className="mt-auto">
        <button
          onClick={onLogout}
          className="w-full py-4 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-colors"
        >
          로그아웃
        </button>
        <p className="text-center text-xs text-gray-300 mt-4">
          버전 1.0.0
        </p>
      </div>
    </div>
  );
}
