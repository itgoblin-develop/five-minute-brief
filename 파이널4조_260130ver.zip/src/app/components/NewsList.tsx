import React from 'react';
import { motion } from 'motion/react';
import { Heart, Bookmark, MessageCircle } from 'lucide-react';
import { NewsItem } from '@/app/data/mockNews';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { getCategoryColor, getRelativeTime, formatCount } from '@/app/utils/helpers';

interface NewsListProps {
  items: NewsItem[];
  likedIds: Set<string>;
  bookmarkedIds: Set<string>;
  onToggleLike: (id: string) => void;
  onToggleBookmark: (id: string) => void;
  onCardClick: (item: NewsItem) => void;
}

export function NewsList({
  items,
  likedIds,
  bookmarkedIds,
  onToggleLike,
  onToggleBookmark,
  onCardClick
}: NewsListProps) {
  return (
    <div className="w-full h-full overflow-y-auto px-4 pb-20 space-y-4 pt-2 no-scrollbar">
      {items.map((item, index) => {
        const isLiked = likedIds.has(item.id);
        const isBookmarked = bookmarkedIds.has(item.id);

        return (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white rounded-[20px] overflow-hidden shadow-sm border border-gray-100 flex p-4 gap-4"
            onClick={() => onCardClick(item)}
          >
            {/* Left: Image (Fixed Size) */}
            <div className="relative w-[110px] h-[110px] shrink-0 rounded-xl overflow-hidden bg-gray-100">
              <ImageWithFallback
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Right: Content */}
            <div className="flex-1 flex flex-col justify-between min-w-0">
              
              {/* Top: Category & Title */}
              <div>
                <div className="mb-1.5 flex items-center">
                  <span className={`inline-block px-2 py-0.5 rounded text-white text-[10px] font-bold tracking-wide ${getCategoryColor(item.category)}`}>
                    {item.category}
                  </span>
                </div>

                <h3 className="text-[16px] font-bold text-gray-900 leading-snug line-clamp-2">
                  {item.title}
                </h3>
              </div>

              {/* Bottom: Date & Actions */}
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-gray-400 font-medium">
                  {getRelativeTime(item.date)}
                </span>

                <div className="flex items-center gap-3">
                  {/* Like */}
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={(e) => { e.stopPropagation(); onToggleLike(item.id); }}
                      className="p-1 rounded-full hover:bg-gray-50 transition-colors"
                    >
                      <Heart 
                        size={16} 
                        className={isLiked ? "fill-[#FF4B4B] text-[#FF4B4B]" : "text-gray-400"} 
                      />
                    </button>
                    <span className="text-[10px] font-medium text-gray-400">
                      {formatCount(item.likeCount + (isLiked ? 1 : 0))}
                    </span>
                  </div>

                  {/* Bookmark */}
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={(e) => { e.stopPropagation(); onToggleBookmark(item.id); }}
                      className="p-1 rounded-full hover:bg-gray-50 transition-colors"
                    >
                      <Bookmark 
                        size={16} 
                        className={isBookmarked ? "fill-[#3D61F1] text-[#3D61F1]" : "text-gray-400"} 
                      />
                    </button>
                    <span className="text-[10px] font-medium text-gray-400">
                      {formatCount(item.bookmarkCount + (isBookmarked ? 1 : 0))}
                    </span>
                  </div>

                  {/* Comment */}
                  <div className="flex items-center gap-1">
                    <button 
                      className="p-1 rounded-full hover:bg-gray-50 transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <MessageCircle size={16} className="text-gray-400" />
                    </button>
                    <span className="text-[10px] font-medium text-gray-400">
                      {formatCount(item.commentCount)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        );
      })}
      
      {items.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <p>표시할 뉴스가 없습니다.</p>
        </div>
      )}
    </div>
  );
}
