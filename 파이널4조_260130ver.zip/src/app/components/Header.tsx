import React from 'react';
import { ArrowLeft, Bell } from 'lucide-react';
import Component5Neul5BunLogo from '@/imports/5Neul5BunLogo';

export type ViewState = 'main' | 'detail' | 'settings' | 'login';

interface HeaderProps {
  currentView: ViewState;
  onBack: () => void;
  onSettingsClick: () => void;
}

export function Header({ currentView, onBack, onSettingsClick }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-transparent z-50 flex items-center justify-between px-4">
      {/* Left Section */}
      <div className="flex items-center min-w-[40px] h-full">
        {currentView === 'main' ? (
          <div className="h-8 w-24 flex items-center">
             <Component5Neul5BunLogo />
          </div>
        ) : (
          <button
            onClick={onBack}
            className="p-2 -ml-2 hover:bg-gray-100 rounded-full transition-colors text-gray-700"
            aria-label="Go back"
          >
            <ArrowLeft size={24} strokeWidth={2.5} />
          </button>
        )}
      </div>

      {/* Center Section (Title for Settings) */}
      <div className="flex-1 flex justify-center">
        {currentView === 'settings' && (
          <span className="text-lg font-bold text-gray-900">설정</span>
        )}
      </div>

      {/* Right Section */}
      <div className="flex items-center justify-end min-w-[40px]">
        {currentView !== 'settings' && currentView !== 'login' && (
          <button
            onClick={onSettingsClick}
            className="p-2 -mr-2 hover:bg-gray-100 rounded-full transition-colors text-gray-700"
            aria-label="Notifications"
          >
            <Bell size={24} className="fill-gray-700 text-gray-700" />
          </button>
        )}
      </div>
    </header>
  );
}
