import React, { useState } from 'react';
import { Toaster, toast } from 'sonner';
import { Bookmark, LayoutTemplate, List } from 'lucide-react';
import { Header, ViewState } from '@/app/components/Header';
import { SwipeDeck } from '@/app/components/SwipeDeck';
import { NewsList } from '@/app/components/NewsList';
import { NewsDetail } from '@/app/components/NewsDetail';
import { Settings } from '@/app/components/Settings';
import { LoginModal } from '@/app/components/LoginModal';
import { BottomNav, Tab } from '@/app/components/BottomNav';
import { MOCK_NEWS, NewsItem } from '@/app/data/mockNews';

export default function App() {
  const [view, setView] = useState<ViewState>('main');
  const [selectedItem, setSelectedItem] = useState<NewsItem | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [readCount, setReadCount] = useState(0);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set());
  const [currentTab, setCurrentTab] = useState<Tab>('home');
  const [viewMode, setViewMode] = useState<'card' | 'list'>('card');

  // Category Tabs
  const categories = ["전체", "트렌딩", "경제", "재테크", "사회"];
  const [activeCategory, setActiveCategory] = useState("전체");

  const handleCardClick = (item: NewsItem) => {
    if (isLoggedIn || readCount < 3) {
      setSelectedItem(item);
      setView('detail');
      
      if (!isLoggedIn) {
        setReadCount(prev => prev + 1);
      }
    } else {
      setShowLoginModal(true);
    }
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
    setShowLoginModal(false);
    toast.success('로그인되었습니다!', {
      description: '이제 모든 뉴스를 무제한으로 즐기세요.'
    });
  };

  const handleToggleLike = (id: string) => {
    setLikedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        if (prev.size === 0 && !isLoggedIn) {
          toast('관심사가 반영됩니다!', {
            description: "AI가 회원님의 취향을 학습해 딱 맞는 뉴스를 추천해요.",
            duration: 4000,
            icon: '❤️'
          });
        }
      }
      return next;
    });
  };

  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        toast('북마크가 해제되었습니다.');
      } else {
        next.add(id);
        toast('기사가 저장되었습니다.', {
          icon: '🔖'
        });
      }
      return next;
    });
  };

  const handleBack = () => {
    if (view === 'detail') {
      setView('main');
      setSelectedItem(null);
    } else if (view === 'settings') {
      setView('main');
    }
  };

  // Filter items based on active category
  const filteredItems = activeCategory === "전체" 
    ? MOCK_NEWS 
    : MOCK_NEWS.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 selection:bg-blue-100 flex flex-col relative overflow-hidden">
      <style>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
      
      <Header
        currentView={view}
        onBack={handleBack}
        onSettingsClick={() => setView('settings')}
      />

      {/* Main Content Area */}
      {/* Subtract header (56px) and bottom nav (64px) heights if on main view */}
      <main className={`pt-14 ${view === 'main' ? 'pb-16 h-[calc(100vh-64px)]' : 'h-full'}`}>
        {view === 'main' && currentTab === 'home' && (
          <div className="h-full flex flex-col">
            {/* Top Controls: Categories + View Toggle */}
            <div className="flex flex-col z-10 bg-gray-50/90 backdrop-blur-sm sticky top-0">
              {/* 1. Categories Row */}
              <div className="w-full overflow-x-auto no-scrollbar px-4 pt-4 pb-2">
                <div className="flex gap-2 min-w-max">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
                        activeCategory === cat
                          ? "bg-black text-white shadow-md shadow-gray-200"
                          : "bg-white text-gray-400 border border-gray-100"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. View Toggle Row (Right aligned) */}
              <div className="flex justify-end px-4 pb-2">
                <div className="bg-white rounded-lg p-1 flex shadow-sm border border-gray-100 h-[38px] items-center">
                  <button 
                    onClick={() => setViewMode('card')}
                    className={`p-1.5 rounded-md transition-all ${
                      viewMode === 'card' 
                        ? 'bg-blue-50 text-[#3D61F1]' 
                        : 'text-gray-300 hover:text-gray-500'
                    }`}
                    aria-label="Card View"
                  >
                    <LayoutTemplate 
                      size={18} 
                      className={viewMode === 'card' ? "fill-current" : ""} 
                    />
                  </button>
                  <button 
                    onClick={() => setViewMode('list')}
                    className={`p-1.5 rounded-md transition-all ${
                      viewMode === 'list' 
                        ? 'bg-blue-50 text-[#3D61F1]' 
                        : 'text-gray-300 hover:text-gray-500'
                    }`}
                    aria-label="List View"
                  >
                    <List 
                      size={18} 
                      className={viewMode === 'list' ? "fill-current" : ""} 
                      strokeWidth={2.5}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Content View */}
            <div className="flex-1 overflow-hidden relative">
              {viewMode === 'card' ? (
                <SwipeDeck
                  items={filteredItems}
                  likedIds={likedIds}
                  bookmarkedIds={bookmarkedIds}
                  onToggleLike={handleToggleLike}
                  onToggleBookmark={handleToggleBookmark}
                  onCardClick={handleCardClick}
                />
              ) : (
                <NewsList
                  items={filteredItems}
                  likedIds={likedIds}
                  bookmarkedIds={bookmarkedIds}
                  onToggleLike={handleToggleLike}
                  onToggleBookmark={handleToggleBookmark}
                  onCardClick={handleCardClick}
                />
              )}
            </div>
          </div>
        )}

        {view === 'main' && currentTab === 'bookmark' && (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <Bookmark size={48} className="mb-4 opacity-20" />
            <p>저장된 기사가 없습니다.</p>
          </div>
        )}

        {view === 'main' && currentTab === 'mypage' && (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <div className="w-16 h-16 bg-gray-200 rounded-full mb-4" />
            <p className="font-bold text-gray-600 mb-1">{isLoggedIn ? "홍길동님" : "로그인이 필요합니다"}</p>
            <p className="text-sm">내 정보를 관리해보세요.</p>
          </div>
        )}

        {view === 'detail' && selectedItem && (
          <NewsDetail item={selectedItem} />
        )}

        {view === 'settings' && (
          <Settings onLogout={() => {
            setIsLoggedIn(false);
            setView('main');
            setReadCount(0);
            toast.info('로그아웃되었습니다.');
          }} />
        )}
      </main>

      {/* Bottom Navigation - Only show on main view */}
      {view === 'main' && (
        <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />
      )}

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onLogin={handleLogin}
      />
      
      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            marginTop: '4rem', // Adjust for header height
          },
          className: 'mt-12' 
        }}
      />
    </div>
  );
}
