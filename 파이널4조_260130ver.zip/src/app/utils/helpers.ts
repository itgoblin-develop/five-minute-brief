export function getCategoryColor(category: string): string {
  switch (category) {
    case '경제': return 'bg-blue-600';
    case '테크': return 'bg-indigo-600';
    case '세계': return 'bg-purple-600';
    case '환경': return 'bg-emerald-600';
    case '문화': return 'bg-pink-600';
    case '사회': return 'bg-orange-600';
    case '재테크': return 'bg-cyan-600';
    case '트렌딩': return 'bg-rose-600';
    default: return 'bg-gray-800';
  }
}

export function getRelativeTime(dateString: string): string {
  // Assuming dateString is "YYYY.MM.DD" or similar format parseable by Date
  const date = new Date(dateString.replace(/\./g, '-'));
  const now = new Date();
  
  // Reset time part for accurate day comparison
  const d1 = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const d2 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
  const diffTime = d2.getTime() - d1.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return '오늘';
  if (diffDays === 1) return '1일 전';
  if (diffDays === 2) return '2일 전';
  if (diffDays === 3) return '3일 전';
  
  return dateString; // Fallback for older dates
}

export function formatCount(count: number): string {
  if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'k';
  }
  return count.toString();
}
